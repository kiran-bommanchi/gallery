import {GET_IMAGES,SORT_VIWES,SORT_SIZE,FETCH_ERROR} from "./actionTypes"
import axios from "axios"

let initState = {
    loading: true,
  };
  let newState = {};
  const firstreducer = (state = {}, action) => {
    switch (action.type) {
      case GET_IMAGES:
          console.log(action.data)
        newState = {
        //   ...state,
          ...action.data,
        };
        return newState;
      case SORT_VIWES:
          console.log(action.data)
          let sortData=action.data.hits.sort((a, b) => a.imageSize < b.imageSize ? 1 : -1)
          console.log(sortData)
        newState = {
            // ...state,
            ...sortData
        };
        return newState
      default:
        return newState;
    }
  };
  
  export default firstreducer;
