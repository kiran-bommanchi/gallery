export const GET_IMAGES = "GET_IMAGES";
export const SORT_VIWES = "SORT_VIWES";
export const SORT_SIZE = "SORT_SIZE";
export const FETCH_ERROR="FETCH_ERROR"
