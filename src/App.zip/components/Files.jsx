import React,{useState,useEffect} from 'react'
import Container from "react-bootstrap/Container";
import {
  Navbar,
  Nav,
  Form,
  FormControl,
  Button,
  Row,
  Col,
  Card,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import axios from "axios";
import { useDispatch, useSelector,connect,shallowEqual } from "react-redux";

function Files(props) {

    // console.log(props)

    const [result,setResult]=useState([])


    const arrayOfPost= useSelector(state=> state.firstreducer,shallowEqual)


    // setResult(arrayOfPost)

    // console.log(arrayOfPost)
    

// setResult(Object.values(props.firstreducer))




    const listOfImages = result.map((singleImage) => {
        // console.log(singleImage);
        return (
          <>
            <Col md={3} style={{ margin: "3px 0px 2px 0px" }}>
              <Card key={singleImage.id}>
                <Card.Img src={singleImage.previewURL}></Card.Img>
              </Card>
              {/* <img src={singleImage.previewURL} /> */}
            </Col>
          </>
        );
      });

    return (
        <>
             <Container fluid>
           <Row>{listOfImages}</Row>
        </Container>
        </>
    )
}

// const mapStateToProps =(state)=>{
//     return{
//         firstreducer:state.firstreducer
//     }
// };

// export default connect(mapStateToProps)(Files)

export default Files
