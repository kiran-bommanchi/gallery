import React,{useState,useEffect,useCallback} from 'react'
import Container from "react-bootstrap/Container";
import {
  Navbar,
  Nav,
  Form,
  FormControl,
  Button,
  Row,
  Col,
  Card,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";


function Header() {
    const [searchText, setSearchTex] = React.useState("");
    const [resultdata,setResultData]=useState([])
    var searchString = searchText.replace(" ", "+");
    console.log(searchString);
    const [sortType, setSortType] = React.useState("");

    let dispatch = useDispatch();
    const setData = useCallback(
        (data) => dispatch({ type: "GET_IMAGES", data }),
        [dispatch]
      );

      function viewSort() {
        dispatch({ type: "SORT_VIWES", data: resultdata });
        // console.log(likes);
        // setSortType("likes");
        // var sortedValues = result.sort((a, b) =>
        //   a.imageSize < b.imageSize ? 1 : -1
        // );
        // setResult(sortedValues);
        // console.log(sortedValues);
      }

      async function getPhotos(searchText) {
        axios
          .get(
            `https://pixabay.com/api/?key=20434978-d7e9466fc3292a133634524e6&q=${searchString}&image_type=photo`
          )
          .then((response) => {
            setData(response.data.hits);
            setResultData(response.data.hits);
          })
          .catch((error) => {
            console.log(error);
          });
      }

      useEffect(() => {
        getPhotos();
      }, [searchText, sortType]);





    return (
        <>
            <Navbar bg="primary" fixed="top" variant="light">
          <Navbar.Brand href="#home">Kiran</Navbar.Brand>
          <Nav className="mx-auto navbar-center">
            <Form inline>
              <FormControl
                type="text"
                onChange={(e) => setSearchTex(e.target.value)}
                placeholder="Search"
                className="mr-sm-2"
              />
              {/* <Button variant="outline-info">Search</Button> */}
            </Form>
          </Nav>
          <Nav className="ml-auto" style={{ marginRight: "5%" }}>
            <Dropdown
              id="dropdown-basic-button"
              // title="Sort"
            >
              <Dropdown.Toggle
                className="fa fa-bars"
                variant="secondary btn-sm"
                id="dropdown-basic"
              ></Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={viewSort}>Views</Dropdown.Item>
                <Dropdown.Item href="#/action-2">Image Size</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
            {/* <i
              id="dropdown-basic-button"
              title="Dropdown button"
              className="fa fa-bars"
              aria-hidden="true"
              onClick={(e) => likeSort("likes")}
            ></i> */}
          </Nav>
        </Navbar>
        </>
    )
}

export default Header
