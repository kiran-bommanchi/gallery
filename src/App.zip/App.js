import logo from "./logo.svg";
import React, { useEffect, useCallback } from "react";
import Navbar from "./components/Navbar";
import Files from "./components/Files";

function App() {
  return (
    <div className="App">
      <header>
        <Navbar />
      </header>
      <main style={{ marginTop: "65px" }}>
        <Files />
      </main>
    </div>
  );
}

export default App;
